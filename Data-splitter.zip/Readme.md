----------- 1# Installing ------------------------

To get started with the project, clone the repository and install the dependencies.

# Install dependencies

[**npm install**]


----------- 2# Running the Application -----------

To start the application in development mode with nodemon (which will automatically restart the server upon changes):

[**npm run dev**]

To start the application in production mode:

[**npm start**]

# Built With

Node.js - The runtime server environment
Express - The web framework used
npm - Dependency Management